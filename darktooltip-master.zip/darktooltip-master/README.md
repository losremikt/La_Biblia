darktooltip
===========

A simple customizable tooltip with confirm option and effects

